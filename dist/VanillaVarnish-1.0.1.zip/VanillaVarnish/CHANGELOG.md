# Changelog

## 1.0.1

- Fixed party buff rendering rejecting combat-secret AuraData records before their permitted display fields reached widgets.
- Refresh known party units when UNIT_AURA supplies a restricted event token.
- Keep valid buff icons visible if a cosmetic stack-count or cooldown setter is refused.
- Added regressions covering combat-secret aura records, events, removal, and cosmetic API failures.

## 1.0.0

- Consolidated NameplateTweaks 2.0.0, QuestTrackerOrganizer 1.2.0, and PartyTweaks 1.0.1 into VanillaVarnish.
- Added one AddOns settings parent with independent Nameplates, Quest tracker, and Party frames master switches.
- Preserved existing nameplate features, swing appearance controls/previews, tracker grouping/folding, and party artwork/aura behavior.
- Added individual party buff and class-color switches with restoration of native spacing and colors.
- Added per-character VanillaVarnish settings, one-time copying of loaded legacy preferences, and safeguards against running duplicate legacy modules.
- Retained legacy feature slash commands and added `/vv` module commands.
- Centralized combat-deferred settings opening, added combined-module regression checks, and provided a clean release packager.
