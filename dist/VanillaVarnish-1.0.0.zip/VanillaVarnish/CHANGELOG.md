# Changelog

## 1.0.0

- Consolidated NameplateTweaks 2.0.0, QuestTrackerOrganizer 1.2.0, and PartyTweaks 1.0.1 into VanillaVarnish.
- Added one AddOns settings parent with independent Nameplates, Quest tracker, and Party frames master switches.
- Preserved existing nameplate features, swing appearance controls/previews, tracker grouping/folding, and party artwork/aura behavior.
- Added individual party buff and class-color switches with restoration of native spacing and colors.
- Added per-character VanillaVarnish settings, one-time copying of loaded legacy preferences, and safeguards against running duplicate legacy modules.
- Retained legacy feature slash commands and added `/vv` module commands.
- Centralized combat-deferred settings opening, added combined-module regression checks, and provided a clean release packager.
